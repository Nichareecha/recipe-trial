package com.example.appflutter662

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
